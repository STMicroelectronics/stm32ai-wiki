# Pasta dataset

This is a sample dataset of pasta built for educational purposes.
The dataset contains images collected using the STM32H747I-DISCO kit with the B-CAMS-OMV camera module.
It contains around 1000 images belonging to 9 classes, all images are in QVGA resolution and RGB depth.

## Labels

- Conchiglie
- Coquillette
- Corti
- Farfalle
- Fusilli
- GreenConchiglie
- Macaroni
- Penne
- RedConchiglie

## Changelog

### v1.0.0 - July 13, 2021

* Initial dataset.

## Author

STMicroelectronics - Artificial Intelligence Solutions (AIS) Team

## License

This work is licensed under the [BSD 3-Clause License](opensource.org/licenses/BSD-3-Clause).
